<!DOCTYPE html> 
<html> 
<head> 
<meta charset="utf-8" />
<title>Renseigner-visiteurMedicale</title>
<link rel="stylesheet" href="<?php echo base_url('/public/css/style.css'); ?>" /> 
</head> 
<?php
echo '<body class="acceuil">';
echo '    <nav>';
echo '        <div class="logo">';
echo '            <img src="' . base_url('public/images/logo.png') . '" alt="Logo">';  // Modifier le chemin de l'image si nécessaire
echo '        </div>';
echo '        <ul>';
echo '            <li><a href="getdata?action=acceuil_visi">Accueil</a></li>';
echo '            <li><a href="getdata?action=renseigner">Renseigner fiche frais</a></li>';
echo '            <li><a href="getdata?action=consulter">Consulter fiche frais</a></li>';
echo '            <li><a href="getdata?action=deconnexion">Déconnexion</a></li>';
echo '        </ul>';
echo '    </nav>';
echo '    <form method="POST" action="">';
echo '        <select id="mois" name="mois">';
echo '            <option value="01">Janvier</option>';
echo '            <option value="02">Février</option>';
echo '            <option value="03">Mars</option>';
echo '            <option value="04">Avril</option>';
echo '            <option value="05">Mai</option>';
echo '            <option value="06">Juin</option>';
echo '            <option value="07">Juillet</option>';
echo '            <option value="08">Août</option>';
echo '            <option value="09">Septembre</option>';
echo '            <option value="10">Octobre</option>';
echo '            <option value="11">Novembre</option>';
echo '            <option value="12">Décembre</option>';
echo '        </select>';
echo '        <input type="submit" name="submit" value="Consulter">';
echo '    </form>';
echo '    <div class="principale">';

// Début de la table pour les frais forfait
echo '        <h2>Fiche Frais pour le</h2>';
echo '        <h4>Les frais forfait du</h4>';
echo '        <table border="1">';
echo '            <tr>';
echo '                <th>Votre Id de visiteur: </th>';
echo '                <th>Date: </th>';
echo '                <th>l\'ID de votre frais: </th>';
echo '                <th>Quantité renseignée: </th>';
echo '            </tr>';
echo '            <tr>';
echo '                <td></td>';
echo '                <td></td>';
echo '                <td></td>';
echo '                <td></td>';
echo '            </tr>';
echo '        </table>';

// Début de la table pour les frais hors forfait
echo '        <h4>Les frais hors forfait du</h4>';
echo '        <table border="1">';
echo '            <tr>';
echo '                <th>Id de la fiche </th>';
echo '                <th>L\'id du visiteur: </th>';
echo '                <th>Le mois de la fiche: </th>';
echo '                <th>Quantité renseignée: </th>';
echo '                <th>La date à laquelle elle a été mise: </th>';
echo '                <th>Le montant en euros: </th>';
echo '            </tr>';
echo '            <tr>';
echo '                <td></td>';
echo '                <td></td>';
echo '                <td></td>';
echo '                <td></td>';
echo '                <td></td>';
echo '                <td></td>';
echo '            </tr>';
echo '        </table>';
echo '    </div>';
echo '</body>';
?>
</html>