<!DOCTYPE html> 
<html> 
<head> 
<meta charset="utf-8" />
<link rel="stylesheet" href="<?php echo base_url('/public/css/style.css'); ?>" /> 
</head> 
<body>
<?php $titre = 'c est GSB'; ?>

<?php 
//echo base_url('/public/css/style.css');
//==========================================================================
// récupération du jeu de données $data, attention on n'accede pas a $data, 
// mais à la variable $resultat définie dans le Controleur via $data['resultat']=$donnees;
// ensuite, on boucle sur les différents tuples résultats via le foreach 
// puis on accède à une donnée en particulier avec la syntaxe : $liste->BIL_TITRE
// BIL_TITRE étant l'attribut défini dans la BDD
//==========================================================================

//liste contenu Blog
echo '<body class="co" style="background-image: url(\''.base_url('public/images/fond_connexion.webp').'\'); background-size: cover; background-position: center;">';
echo '<section>';
echo '<center><h1>Bienvenue sur GSB</h1></center>';
echo '<br>';
echo '<center><p>Veuillez choisir votre interface de connexion à Galaxy Swiss Bourdin</p></center>';
echo '<br>';
echo '<center><a href="getdata?action=visiteur" class="zone-cliquable">Visiteur Médical</a></center>';
echo '<br>';
echo '<center><a href="getdata?action=compta" class="zone-cliquable">Comptable</a></center>';
echo '<br>';
echo '</section>';
echo '</body>';



//==========================================================================
// on boucle pour chaque ligne de résultat de la requete sql
// on stocke chaque ligne dans une variable $liste
//==========================================================================


//==========================================================================
// on on affiche le titre et date des billets présents en BDD
// via $liste qui ne contien qu'une ligne de résultat
//==========================================================================
?>
</body>
</html>