<!DOCTYPE html> 
<html> 
<head> 
<meta charset="utf-8" />
<link rel="stylesheet" href="<?php echo base_url('/public/css/style.css'); ?>" /> 
</head> 
<body>
<?php $titre = 'Billet'; ?>

<?php
echo '<body class="co" style="background-image: url(\''.base_url('public/images/fond_connexion.webp').'\'); background-size: cover; background-position: center;">';
echo '    <div class="container">';
echo '        <h4>Vous connecter à votre compte de comptable</h4>';
echo '        <p id="infosco">Veuillez entrer vos informations ci-dessous :</p>';
echo '        <div class="monBloc">';
echo '        <form action="' . base_url('Controleur/accueil_compta') . '" method="POST">';  // Changer l'action pour rediriger via un contrôleur
echo '            <label for="username">Login:</label>';
echo '            <input type="text" id="username" name="username" required>';
echo '            <label for="password">Mot de passe:</label>';
echo '            <input type="password" id="password" name="password" required>';
echo '            <input type="submit" value="Se connecter">';
echo '        </form>';
echo '        <p>Vous n\'avez pas de compte ? <a href="' . base_url('Controleur/inscription_compta') . '">Créer un compte</a></p>';  // Modifier le lien pour utiliser base_url
echo '        </div>';
echo '    </div>';
echo '</body>';
?>

</body>
</html>